HW7 assignment:

Adding tabs with check box so that new tables can be created in a new tab. One or more tabs can be selected to remove the checked tabs. I used Slider range inputs to give the user the option to enter values using the slider that updates the text box or the user can edit the text box that update the sliders range. 

I used W3schools, Stackoverflow, api.jqueryui.com to complete this assignment. 

Links:

https://mali-ali.github.io/sandbox/HW7/MultiplicationTable-HW7.html

https://github.com/mali-ali/sandbox