# mywebsite
Bootstrap assignment for personal website
This is the solution to HW4 assignment for COMP 4610 Class.
The purpose of this assignment is to enhance my personal website using the tools of HTML and Bootstrap.
Bootstrap is front-end open source toolkit that uses responsive grid system.

 [github website link HW4](https://mali-ali.github.io/sandbox/)
 
 [UML website link HW4](http://www.cs.uml.edu/~mali/HW4/index.html)
	
 [Homework 2](http://www.cs.uml.edu/~mali/)

I used the following sites to help me with my website

[Get Bootstrap] (https://getbootstrap.com/)

[W3Schools] (https://www.w3schools.com/bootstrap4/default.asp)